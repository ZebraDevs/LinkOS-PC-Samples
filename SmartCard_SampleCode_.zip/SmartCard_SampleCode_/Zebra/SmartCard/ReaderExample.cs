﻿using System;

namespace SmartCardExampleCode.Zebra.SmartCard {

    internal class ReaderSlotExample {

        #region Properties
        internal bool isSIOCard { get; set; } = false;
        internal string version { get; set; } = string.Empty;
        #endregion

    }
}
